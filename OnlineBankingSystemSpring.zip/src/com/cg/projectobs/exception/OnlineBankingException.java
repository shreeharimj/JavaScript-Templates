package com.cg.projectobs.exception;


public class OnlineBankingException extends Exception{

	public OnlineBankingException(String errormessage)
	{
		super(errormessage);
	}
}
