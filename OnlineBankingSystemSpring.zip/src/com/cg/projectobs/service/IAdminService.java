package com.cg.projectobs.service;

import java.util.List;

import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;

public interface IAdminService {

	public boolean login(String userName, String password);
	public List<ServiceBean> viewAllServices();
	public int modifyRR(ServiceBean service);
	public int modifych(ServiceBean service);

	public List<TransactionBean> getData(String input) throws OnlineBankingException;
}
