package com.cg.projectobs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.dao.IAdminDao;
import com.cg.projectobs.exception.OnlineBankingException;

@Service
public class AdminServiceImpl implements IAdminService{

	@Autowired
	private IAdminDao adminDao;
	@Override
	public boolean login(String userName, String password) {
	return adminDao.login(userName, password);
	}
	@Override
	public List<TransactionBean> getData(String input)
			throws OnlineBankingException {
		return adminDao.getData(input);
	}
	@Override
	public List<ServiceBean> viewAllServices() {
		return adminDao.viewAllServices();
	}
	@Override
	public int modifyRR(ServiceBean service) {
		return adminDao.modifyRR(service);
	}
	@Override
	public int modifych(ServiceBean service) {
		return adminDao.modifych(service);
	}

}
