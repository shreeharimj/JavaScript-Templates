package com.cg.projectobs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.projectobs.bean.AccountMasterBean;
import com.cg.projectobs.bean.CustomerBean;
import com.cg.projectobs.bean.FundTransferBean;
import com.cg.projectobs.bean.PayeeBean;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.bean.UserBean;
import com.cg.projectobs.dao.ICustomerDao;
import com.cg.projectobs.exception.OnlineBankingException;

@Service
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	private ICustomerDao custDao;
	
	public ICustomerDao getCustDao() {
		return custDao;
	}

	public void setCustDao(ICustomerDao custDao) {
		this.custDao = custDao;
	}


	@Override
	public boolean addCustomer(CustomerBean custbean,
			AccountMasterBean accountbean, UserBean userbean,ServiceBean service) {
		return custDao.addCustomer(custbean, accountbean, userbean,service);
	}

	@Override
	public UserBean login(int userId, String password) {
		return custDao.login(userId, password);
	}

	@Override
	public boolean addPayee(PayeeBean payee,int id) throws OnlineBankingException {
		return custDao.addPayee(payee, id);
	}

	@Override
	public List<PayeeBean> viewAllPayees(int id) {
		return custDao.viewAllPayees(id);
	}

	@Override
	public boolean transferAmountToBenificiary(PayeeBean payee,
			TransactionBean trans, FundTransferBean fund, int id) {
		return custDao.transferAmountToBenificiary(payee, trans, fund, id);
	}

	@Override
	public int modifyAddress(String address,int id) {
		return custDao.modifyAddress(address,id);
	}

	@Override
	public int checkBalance(int id) {
		return custDao.checkBalance(id);
	}

	@Override
	public List<TransactionBean> viewMiniStatement(int id) {
		return custDao.viewMiniStatement(id);
	}

	@Override
	public boolean addChequeRequest(ServiceBean service, int id) {
		return custDao.addChequeRequest(service, id);
	}

	@Override
	public int modifyPass(String password, int id) {
		return custDao.modifyPass(password, id);
	}

	@Override
	public ServiceBean checkStatus(int id) {
		return custDao.checkStatus(id);
	}

	

}
