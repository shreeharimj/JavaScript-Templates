package com.cg.projectobs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "customer")
public class CustomerBean {

	@Column(name = "account_id")
	private int accountId;

	@NotEmpty(message = "Customer name cannot be empty!!")
	@Pattern(regexp = "^[A-Za-z\\s]{3,}[.]{0,1}[A-Za-z\\s]{0,}$", message = "Enter only alphabets,spaces or period")
	@Column(name = "customer_name")
	private String customerName;

	@Id
	@NotEmpty(message = "Email cannot be empty!!")
	@Email(message = "Enter a valid email")
	@Column(name = "email")
	private String emailId;

	@NotEmpty(message = "Address cannot be empty!!")
	@Pattern(regexp = "^[#.0-9a-zA-Z\\s,-]+$", message = "Enter a valid Address")
	@Column(name = "address")
	private String address;

	@NotEmpty(message = "Pancard cannot be empty!!")
	@Pattern(regexp = "^([a-zA-Z]{5})([0-9]{4})([a-zA-Z]{1})$", message = "Enter a valid pancard number which has 5 alphabets followed by 4 digits and 1 letter")
	@Column(name = "pancard")
	private String pancard;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

}
