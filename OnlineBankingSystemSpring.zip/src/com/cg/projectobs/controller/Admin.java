package com.cg.projectobs.controller;

import java.util.ArrayList;
import java.util.List;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.projectobs.bean.Login;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;
import com.cg.projectobs.service.IAdminService;

@Controller
@RequestMapping("*.adm")
public class Admin {
	@Autowired
	private IAdminService adminService;

	public IAdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(IAdminService adminService) {
		this.adminService = adminService;
	}

	@RequestMapping("/backhomeadmin")
	public ModelAndView backpage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("backhomeadmin");
		return mv;

	}

	@RequestMapping("/login")
	public ModelAndView showloginpage() {
		Login login = new Login();
		return new ModelAndView("login", "login", login);

	}

	@RequestMapping("/loginValidateAdmin")
	public ModelAndView loginValidate(@ModelAttribute("login")@Valid Login login,
			BindingResult result) {

		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			Boolean flag2 = adminService.login(login.getUserName(),
					login.getPassword());
			if (flag2 != false) {
				mv = new ModelAndView("homeadmin");

			} else {
				mv.addObject("login", login);
				mv.addObject("isFirst", false);
				mv.addObject("message", "Login Failed");
				mv.setViewName("login");
			}
		} else {
			mv.addObject("login", login);
			mv.addObject("isFirst", false);
			mv.addObject("message", "Login Failed");
			mv.setViewName("login");
		}

		return mv;

	}

	@RequestMapping("/selecttransactions")
	public String getViewTransactions() {
		return "selecttransactions";
	}

	@RequestMapping("/transactioninput")
	public ModelAndView getTransactionInput(
			@RequestParam("value") String input) {
		ModelAndView mv = new ModelAndView();
		if ("daily".equals(input))
			mv.addObject("inputFormat", "(dd-mm-yyyy)");
		else if ("monthly".equals(input))
			mv.addObject("inputFormat", "(mm-yyyy)");
		else if ("yearly".equals(input))
			mv.addObject("inputFormat", "(yyyy)");
		mv.setViewName("selecttransactions");
		mv.addObject("datereview", 1);
		return mv;
	}

	@RequestMapping("/transaction")
	public ModelAndView getTransactions(@RequestParam("input") String input) {
		ModelAndView mv = new ModelAndView();
		List<TransactionBean> transactionList = new ArrayList<TransactionBean>();

		try {
			transactionList = adminService.getData(input);
			if (transactionList.isEmpty()) {
				mv.addObject("Message", "No transactions on Given Date");
				mv.setViewName("selecttransactions");
				mv.addObject("datereview", 2);
			} else {
				mv.addObject("input", input);
				mv.addObject("tList", transactionList);
				mv.addObject("datereview", 3);
				mv.setViewName("selecttransactions");
			}
		} catch (OnlineBankingException exception) {
			mv.addObject("Message", "Enter in proper format");
			mv.addObject("datereview", 2);
			mv.setViewName("selecttransactions");

		}
		return mv;
	}

	@RequestMapping("/viewservices")
	public ModelAndView viewservices() {
		ModelAndView mv = new ModelAndView();
		List<ServiceBean> list = adminService.viewAllServices();
		if (list.isEmpty()) {
			mv.setViewName("homeadmin");
			mv.addObject("message", "No Services Available");
			mv.addObject("service", 1);
		} else {
			mv.setViewName("viewservices");
			mv.addObject("list", list);
			mv.addObject("updaterr",10);

		}
		return mv;
	}

	@RequestMapping("/updatereg")
	public ModelAndView updateReg() {

		ModelAndView mv = new ModelAndView();
		ServiceBean serv = new ServiceBean();
		mv.addObject("service", serv);
		mv.setViewName("viewservices");
		mv.addObject("updaterr",1);
		return mv;

	}
	
	@RequestMapping("/updaterr")
	public ModelAndView update(@ModelAttribute("service")ServiceBean service,BindingResult result)
	{
		ModelAndView mv=new ModelAndView();
		try {
			int id = adminService.modifyRR(service);
			if (id > 0) {
				mv.setViewName("viewservices");
				mv.addObject("message", "Updated Successfully!!");
				mv.addObject("updaterr", 2);
			} else {
				mv.setViewName("viewservices");
				mv.addObject("service", service);
				mv.addObject("message", "Updation not successful!!The id does not exist!!");
				mv.addObject("updaterr", 3);

			}
		} catch (Exception e) {
			mv.setViewName("viewservices");
			mv.addObject("service", service);
			mv.addObject("message", "This Service Id is already activated!!");
			mv.addObject("updaterr", 4);
		}

		return mv;
	}
	
	@RequestMapping("/updatecheque")
	public ModelAndView updateCheque() {

		ModelAndView mv = new ModelAndView();
		ServiceBean serv = new ServiceBean();
		mv.addObject("service", serv);
		mv.setViewName("viewservices");
		mv.addObject("updatech",1);
		return mv;

	}
	@RequestMapping("/updatech")
	public ModelAndView updatech(@ModelAttribute("service")ServiceBean service,BindingResult result)
	{
		ModelAndView mv=new ModelAndView();
		try {
			int id = adminService.modifych(service);
			if (id > 0) {
				mv.setViewName("viewservices");
				mv.addObject("message", "Updated Successfully!!");
				mv.addObject("updatech", 2);
			} else {
				mv.setViewName("viewservices");
				mv.addObject("service", service);
				mv.addObject("message", "Updation not successful!!The id does not exist or it is already activated!!");
				mv.addObject("updatech", 3);

			}
		} catch (Exception e) {
			mv.setViewName("viewservices");
			mv.addObject("service", service);
			mv.addObject("message", "This Service Id is already activated!!");
			mv.addObject("updatech", 4);
		}

		return mv;
	}
	
	@RequestMapping("/aboutus")
	public ModelAndView aboutUs()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("aboutus");
		return mv;
	}
	@RequestMapping("/contactus")
	public ModelAndView contactUs()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("contactus");
		return mv;
	}
}
