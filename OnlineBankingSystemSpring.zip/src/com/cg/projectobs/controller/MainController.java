package com.cg.projectobs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("*.main")
public class MainController {
	@RequestMapping("/home")
	public ModelAndView showHome() {
		return new ModelAndView("welcome");
	}
}
