package com.cg.projectobs.dao;

import java.util.List;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;

/*******************************************************************************************************
- Class Name	:	IAdminDao
- Author		:	Swathi Anandram, Roshni P G
- Creation Date	:	15/02/2018
- Description	:	Interface for dao for admin
********************************************************************************************************/
public interface IAdminDao {
	
	public boolean login(String username, String password);
	public List<ServiceBean> viewAllServices();
	public List<TransactionBean> getData(String input) throws OnlineBankingException;
	public int modifyRR(ServiceBean service);
	public int modifych(ServiceBean service);
}
