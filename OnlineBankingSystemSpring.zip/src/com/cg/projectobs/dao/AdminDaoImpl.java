package com.cg.projectobs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.projectobs.bean.Login;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;

/*******************************************************************************************************
 * - Class Name : AdminDaoImpl - Author : Swathi Anandram, Roshni P G - Creation
 * Date : 15/02/2018 - Description : Dao Layer for Admin
 ********************************************************************************************************/
@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao {

	@PersistenceContext
	private EntityManager entityManager;

	/*******************************************************************************************************
	 * - Function Name : login(String username, String password) - Input
	 * Parameters : String username, String password - Return Type : boolean -
	 * Throws : OnlineBankingException - Author : Swathi Anandram, Roshni P G -
	 * Creation Date : 15/02/2018 - Description : Login for Admin
	 ********************************************************************************************************/
	@Override
	public boolean login(String username, String password) {
		Login bean = entityManager.find(Login.class, username);
		boolean flag = false;
		if (bean != null) {
			if (bean.getPassword().equals(password)) {
				flag = true;
			} else {
				flag = false;
			}
		}
		return flag;
	}

	/*******************************************************************************************************
	 * - Function Name : getData(String input) - Input Parameters : String input
	 * - Return Type : List<TransactionBean> - Throws : OnlineBankingException -
	 * Author : Swathi Anandram, Roshni P G - Creation Date : 15/02/2018 -
	 * Description : Listing the transactions
	 ********************************************************************************************************/

	@Override
	public List<TransactionBean> getData(String input)
			throws OnlineBankingException {
		TypedQuery<TransactionBean> query = entityManager
				.createQuery(
						"SELECT t FROM TransactionBean t WHERE to_char(dateOfTransaction,'DD-MM-YYYY') like :input",
						TransactionBean.class);
		query.setParameter("input", "%" + input);
		return query.getResultList();
	}

	/*******************************************************************************************************
	 * - Function Name : viewAllServices() - Input Parameters : void - Return
	 * Type : List<ServiceBean> - Throws : OnlineBankingException - Author :
	 * Swathi Anandram, Roshni P G - Creation Date : 15/02/2018 - Description :
	 * Listing the services
	 ********************************************************************************************************/
	@Override
	public List<ServiceBean> viewAllServices() {
		TypedQuery<ServiceBean> query = entityManager.createQuery(
				"FROM ServiceBean", ServiceBean.class);
		return query.getResultList();
	}

	@Override
	public int modifyRR(ServiceBean service) {
		Query query1 = entityManager
				.createQuery("UPDATE ServiceBean SET serviceStatus=? WHERE serviceId=? AND serviceDescription=? AND serviceStatus=?");
		query1.setParameter(1, "ACTIVATED");
		query1.setParameter(2, service.getServiceId());
		query1.setParameter(3, "REGISTRATION REQUEST");
		query1.setParameter(4, "PENDING");

		int count = query1.executeUpdate();
		return count;
	}

	@Override
	public int modifych(ServiceBean service) {
		Query query1 = entityManager
				.createQuery("UPDATE ServiceBean SET serviceStatus=? WHERE serviceId=? AND serviceDescription=? AND serviceStatus=?");
		query1.setParameter(1, "ACTIVATED");
		query1.setParameter(2, service.getServiceId());
		query1.setParameter(3, "CHEQUE BOOK REQUEST");
		query1.setParameter(4, "PENDING");

		int count = query1.executeUpdate();
		return count;
	}

}
