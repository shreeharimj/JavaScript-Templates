package com.cg.projectobs.dao;

import java.util.List;

import com.cg.projectobs.bean.AccountMasterBean;
import com.cg.projectobs.bean.CustomerBean;
import com.cg.projectobs.bean.FundTransferBean;
import com.cg.projectobs.bean.PayeeBean;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.bean.UserBean;
import com.cg.projectobs.exception.OnlineBankingException;
/*******************************************************************************************************
- Class Name	:	ICustomerDao
- Author		:	Swathi Anandram, Roshni P G
- Creation Date	:	15/02/2018
- Description	:	Interface for dao for customer
********************************************************************************************************/
public interface ICustomerDao {

	public boolean addCustomer(CustomerBean custbean,AccountMasterBean accountbean,UserBean userbean,ServiceBean service);
	public UserBean login(int userId, String password);
	public boolean addPayee(PayeeBean payee,int id) throws OnlineBankingException;
	public List<PayeeBean> viewAllPayees(int id);
	
	public boolean transferAmountToBenificiary(PayeeBean payee, TransactionBean trans,
			FundTransferBean fund, int id);

	public int modifyAddress(String address, int id);
	public int checkBalance(int id);
	public List<TransactionBean> viewMiniStatement(int id);
	public boolean addChequeRequest(ServiceBean service,int id);
	public int modifyPass(String password, int id);
	public ServiceBean checkStatus(int id);

}
