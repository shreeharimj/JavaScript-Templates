package com.project.obs.bean;

import java.util.Date;

public class TransactionBean {
	
	private int transactionId;
	private String transactionDescription;
	private Date dateofTransaction;
	private String transactionType;
	private int transactionAmount;
	private int accountNo;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public Date getDateofTransaction() {
		return dateofTransaction;
	}
	public void setDateofTransaction(Date dateofTransaction) {
		this.dateofTransaction = dateofTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public TransactionBean() {
		super();
	}
	public TransactionBean(int transactionId, String transactionDescription,
			Date dateofTransaction, String transactionType,
			int transactionAmount, int accountNo) {
		super();
		this.transactionId = transactionId;
		this.transactionDescription = transactionDescription;
		this.dateofTransaction = dateofTransaction;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.accountNo = accountNo;
	}
	
	

}
