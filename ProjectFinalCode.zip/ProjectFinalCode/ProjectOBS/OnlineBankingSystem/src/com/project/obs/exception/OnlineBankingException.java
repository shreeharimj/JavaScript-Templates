package com.project.obs.exception;

public class OnlineBankingException extends Exception{

	public OnlineBankingException(String errormessage)
	{
		super(errormessage);
	}
}
