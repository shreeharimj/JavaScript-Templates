package com.project.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.project.obs.bean.ServiceBean;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.util.DBConnection;

public class AdminDaoImpl implements IAdminDao {

	private static Logger log = Logger.getLogger(AdminDaoImpl.class);

	public AdminDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public boolean updateRegStatus(int serviceId) throws OnlineBankingException {
		log.debug("Update Register Status Called");
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		String query = QueryMapper.SET_REQUEST_STATUS;
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "ACTIVATED");
			pstmt.setString(2, "PENDING");
			pstmt.setString(3, "REGISTRATION REQUEST");
			pstmt.setInt(4, serviceId);

			int count = pstmt.executeUpdate();
			if (count <= 0) {
				log.info("Updation Failed");
				return false;
			}

		} catch (SQLException e) {
			log.error(e);
			System.out.println("Cannot be updated");
		}
		log.debug("Update Register Status Completed");
		return true;

	}

	@Override
	public boolean updateCheckBookStatus(int serviceId)
			throws OnlineBankingException {
		log.debug("Update CheckBook Status Called");
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		String query = QueryMapper.SET_REQUEST_STATUS;
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "ACTIVATED");
			pstmt.setString(2, "Pending");
			pstmt.setString(3, "Cheque Book Request");
			pstmt.setInt(4, serviceId);

			int count = pstmt.executeUpdate();
			if (count <= 0) {
				log.info("Updation Failed");
				return false;
			}

		} catch (SQLException e) {
			log.error(e);
			System.out.println("Cannot be updated");
		}
		log.debug("Update CheckBook Status Completed");
		return true;
	}

	@Override
	public List<ServiceBean> getServiceIdOfCustomer()
			throws OnlineBankingException {
		log.debug("Listing Services Called");
		List<ServiceBean> list = new ArrayList<ServiceBean>();

		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		String query = QueryMapper.GET_ALL_SERVICE;
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				ServiceBean bean1 = new ServiceBean();
				bean1.setAccountId(rst.getInt("account_id"));
				bean1.setServiceDescription(rst
						.getString("service_description"));
				bean1.setServiceId(rst.getInt("service_id"));
				bean1.setServiceStatus(rst.getString("service_status"));
				bean1.setServiceRaisedDate(rst.getDate("service_raised_date"));
				list.add(bean1);

			}
		} catch (SQLException e) {
			log.error(e);
			System.out.println("Cannot fetch details");
		}
		log.debug("Listing Service Completed");
		return list;
	}

}
