package com.project.obs.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.User;
import com.project.obs.dao.IUserDao;
import com.project.obs.dao.UserDaoImpl;
import com.project.obs.exception.OnlineBankingException;

public class UserServiceImpl implements IUserService {

	IUserDao dao = new UserDaoImpl();

	@Override
	public String getRole(String unm, String pwd) throws OnlineBankingException {

		String role = null;
		User user = dao.getUserByName(unm);
		if (user == null)
			throw new OnlineBankingException("No Such UserName");
		else if (!pwd.equals(user.getPassword()))
			throw new OnlineBankingException("Password Mismatch");
		else
			role = user.getRole();
		return role;

	}

	@Override
	public CustomerBean validateCustomer(CustomerBean customer)
			throws OnlineBankingException {
		return dao.validateCustomer(customer);

	}

	@Override
	public int addCustomerDetails(CustomerBean customer)
			throws OnlineBankingException {

		return dao.addCustomerDetails(customer);

	}

	@Override
	public ServiceBean checkStatus(ServiceBean service)
			throws OnlineBankingException {
		return dao.checkStatus(service);
	}

	
/*
	@Override
	public boolean isValid(CustomerBean bean) throws OnlineBankingException {

		if (!validateName(bean.getCustomerName()))
			throw new OnlineBankingException(
					"Name not valid. Please enter only Alphabets.");
		else if (!validateAddress(bean.getAddress()))
			throw new OnlineBankingException(
					"Address not valid. Please enter a valid address.");
		else if (!validateEmail(bean.getEmailId()))
			throw new OnlineBankingException("Email not valid");
		else if (!validatePan(bean.getPancard()))
			throw new OnlineBankingException(
					"PanCard not valid. Please enter a proper Id");
		else if (!validateUserId(bean.getUserId()))
			throw new OnlineBankingException(
					"User Id not valid. Please enter only digits with minimum 4 digits");
		else if (!validateUserPassword(bean.getLoginPassword()))
			throw new OnlineBankingException(
					"Password is not strong enough. At least 8 chars, At least one digit, At least one lower alpha char and one upper alpha char, At least one char within a set of special chars (@#%$^), Should not contain spaces and tabs");
		else if (!validateQuestion(bean.getSecretQuestion()))
			throw new OnlineBankingException(
					"Question is not proper. Please enter only alphabets");
		else if (!validateAnswer(bean.getTransactionPassword()))
			throw new OnlineBankingException(
					"Answer is not proper. Please enter only alphabets");
		return true;

	}*/

	public boolean validateName(String fname) {
		Pattern pattern = Pattern
				.compile("^[A-Za-z\\s]{1,}[.]{0,1}[A-Za-z\\s]{0,}$");
		Matcher matcher = pattern.matcher(fname);
		return matcher.matches();
	}

	public boolean validateEmail(String email) {
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	public boolean validateAddress(String address) {
		Pattern pattern = Pattern.compile("^[#.0-9a-zA-Z\\s,-]+$");
		Matcher matcher = pattern.matcher(address);
		return matcher.matches();
	}

	public boolean validatePan(String pan) {
		Pattern pattern = Pattern
				.compile("^([a-zA-Z]{5})([0-9]{4})([a-zA-Z]{1})$");
		Matcher matcher = pattern.matcher(pan);
		return matcher.matches();
	}

	public boolean validateUserId(int number) {
		Pattern pattern = Pattern.compile("^[0-9]{4,}$");
		Matcher matcher = pattern.matcher(String.valueOf(number));
		return matcher.matches();
	}

	public boolean validateUserPassword(String pass) {
		Pattern pattern = Pattern
				.compile("^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$");
		Matcher matcher = pattern.matcher(String.valueOf(pass));
		return matcher.matches();
	}

	public boolean validateQuestion(String quest) {
		Pattern pattern = Pattern.compile("^[A-Za-z\\s]{1}[a-zA-Z\\s]*$");
		Matcher matcher = pattern.matcher(quest);
		return matcher.matches();
	}

	public boolean validateAnswer(String ans) {
		Pattern pattern = Pattern.compile("^[A-Za-z\\s]{1}[a-zA-Z\\s]*$");
		Matcher matcher = pattern.matcher(ans);
		return matcher.matches();
	}

	public boolean validateDigits(int num) {
		Pattern pattern = Pattern.compile("^[0-9]+$");
		Matcher matcher = pattern.matcher(String.valueOf(num));
		return matcher.matches();
	}

}

