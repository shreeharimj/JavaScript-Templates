package com.project.obs.pl;

import java.util.List;
import java.util.Scanner;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.TransactionBean;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.service.CustomerServiceImpl;
import com.project.obs.service.IAdminService;
import com.project.obs.service.ICustomerService;

public class UserConsole {

	private ICustomerService service = new CustomerServiceImpl();
	private Scanner sc;
	private int currentUser;
	CustomerBean customer = new CustomerBean();

	public UserConsole(int userid) {
		this.currentUser = userid;
	}

	public void start() {
		
		try {
			while (true) {
				sc = new Scanner(System.in);
				System.out.println("[1] Update your Address");
				System.out.println("[2] Update your Login Password");
				System.out.println("[3] Add Beneficiary");
				System.out.println("[4] View your Beneficiaries");
				System.out.println("[5] Ask for Cheque Book");
				System.out.println("[6] Get cheque book status");
				System.out.println("[7] Get mini statement");
				System.out.println("[8] Check your balance");
				System.out.println("[9] Transfer Amount to Beneficiary");
				System.out.println("[10] Log Out");
				System.out.println("**************************************");
				System.out.println("Enter your choice");
				int choice = sc.nextInt();
				sc.nextLine();
				switch (choice) {

				case 1:
					CustomerBean bean = new CustomerBean();
					System.out.println("Enter your account number");
					int acnum = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the new Address");
					String address1 = sc.nextLine();
					bean.setAccountId(acnum);
					bean.setAddress(address1);
					try {

						boolean flag = service.updateAddress(bean);

						if (flag == true) {
							System.out.println("Address is updated successfully!!");
							System.out.println("The new Address is");
							System.out.println(bean.getAddress());
							System.out
									.println("*************************************");
						} else
							System.out.println("Address not Updated");
					} catch (OnlineBankingException e) {
						System.out.println("Exception in updation");
					}
					break;

				case 2:
					System.out.println("Enter the account id");
					int acc = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the old password");
					String oldpass = sc.nextLine();
					System.out.println("Enter the new password");
					String newpass = sc.nextLine();
					try {
						boolean flag = service
								.updatePassword(oldpass, acc, newpass);
						if (flag == true) {
							System.out
									.println("Login Password Updated Successfully");
							System.out
									.println("**************************************");
						} else
							System.out.println("Password cannot be updated");
					} catch (OnlineBankingException e) {
						System.out.println("Password not Updated");
					}

					break;

				case 3:
					try {
						System.out.println("Payee Details");
						System.out.println("Enter Account ID");
						int accid = sc.nextInt();
						System.out.println("Enter PayeeAccountID:");
						int payeeAccountId = sc.nextInt();
						sc.nextLine();
						System.out.println("Enter Payee NickName:");
						String nickName = sc.nextLine();
						customer.setAccountId(accid);
						customer.setPayeeAccountId(payeeAccountId);
						customer.setNickName(nickName);

						int id = service.addPayeeDetails(customer);
						if (id < 0) {
							throw new OnlineBankingException("Payee not added");
						} else {
							System.out.println(customer.getPayeeAccountId() + " "
									+ customer.getNickName());
							System.out.println("Payee Added Successfully");
							System.out
									.println("****************************************");
						}
					} catch (OnlineBankingException e) {
						System.out.println("Sorry!! Cannot Add Payee Details. The payee with that nick name already exists! or You have entered wrong credentials!!");
					} catch (Exception e1) {
						System.out.println("Enter the details properly!!");
					}
					break;

				case 4:
					try {
						System.out.println("Enter the AccountID");
						int accountId = sc.nextInt();
						List<CustomerBean> list = service.getBenificiary(accountId);

						for (CustomerBean customer1 : list) {
							System.out.println(customer1.getAccountId() + " "
									+ customer1.getPayeeAccountId() + " "
									+ customer1.getNickName());

						}
						System.out
								.println("****************************************");
					} catch (OnlineBankingException e) {
						System.out.println("Exception Occured " + e.getMessage());
					}

					break;

				case 5:

					System.out.println("Enter Account ID");
					int accountid = sc.nextInt();
					sc.nextLine();

					try {
						ServiceBean bean1 = new ServiceBean();
						bean1.setAccountId(accountid);
						int count = service.addCheckRequestDetails(bean1);
						if (count <= 0) {
							throw new OnlineBankingException(
									"Cheque request cannot be completed");
						} else {
							System.out.println("Cheque request completed");
							System.out
									.println("****************************************");
						}
					} catch (OnlineBankingException e) {
						System.out.println("Exception in cheque");
					}
					break;

				case 6:
					try {
						System.out.println("Enter Account Id");
						int acntid = sc.nextInt();

						ServiceBean servbean = new ServiceBean();
						servbean.setAccountId(acntid);

						ServiceBean servicebean = service
								.getChequeBookStatus(servbean);
						System.out.println("Cheque Book Request:");
						System.out.println("Status: "
								+ servicebean.getServiceStatus());
						System.out
								.println("******************************************");
					} catch (OnlineBankingException e1) {
						System.out.println("Sorry!!");
					}
					break;

				case 7:
					System.out.println("Enter Account Id");
					int accountid1 = sc.nextInt();
					TransactionBean bean1 = new TransactionBean();
					try {
						List<TransactionBean> list = service
								.viewAllTransferDetails(accountid1);
						if (list.isEmpty()) {
							System.out.println("There are no transactions!!!");
							System.out
									.println("***************************************");
						} else {
							for (TransactionBean tranbean : list) {
								System.out.println("Transaction Account Number "
										+ tranbean.getAccountNo());
								System.out.println("Transaction Amount "
										+ tranbean.getTransactionAmount());
								System.out.println("Transaction Description "
										+ tranbean.getTransactionDescription());
								System.out.println("Transaction Id "
										+ tranbean.getTransactionId());
								System.out.println("Transaction Type "
										+ tranbean.getTransactionType());
								System.out.println("Transaction Date "
										+ tranbean.getDateofTransaction());
								System.out
										.println("****************************************");
							}
						}
					} catch (OnlineBankingException e) {
						System.out.println("Exception " + e.getMessage());
					}

					break;

				case 8:
					System.out
							.println("Enter the Account Id to check your balance");
					int accountidd = sc.nextInt();
					try {
						CustomerBean bean11 = service.checkBalance(accountidd);
						System.out.println("Your current balance is "
								+ bean11.getAccountBalance());
						System.out
								.println("****************************************");
					} catch (OnlineBankingException e) {
						System.out.println("Exception " + e.getMessage());
					}
					break;

				case 9:
					System.out.println("Enter your account Id");
					int aid = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter payee nickname");
					String nick = sc.nextLine();
					System.out.println("Enter the amount to be transferred");
					int amount = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the transaction description");
					String description = sc.nextLine();
					System.out.println("Enter transaction type:");
					System.out.println("Type D for Deposit");
					String types = sc.nextLine();

					try {
						service.TransferAmountToBenificiary(aid, nick, amount,
								description, types);

						System.out.println("Amount transferred Successfully");

						CustomerBean beans = service.checkBalance(aid);
						System.out.println("Your current balance is "
								+ beans.getAccountBalance());
						System.out
								.println("****************************************");
					} catch (OnlineBankingException e) {
						System.out.println("Exception " + e.getMessage());
					}

					break;

				case 10:
					System.out.println("Thank you for using our services!!");
					System.out.println("****************************************");
					System.exit(0);

				}

			}
		} catch (Exception e) {
			System.out.println("Please enter in proper format");
			System.out.println("**********************************************");
			start();
		}
	}
}
