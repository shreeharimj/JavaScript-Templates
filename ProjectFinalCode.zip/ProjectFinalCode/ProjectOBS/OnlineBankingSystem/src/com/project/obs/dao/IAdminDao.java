package com.project.obs.dao;

import java.util.List;

import com.project.obs.bean.ServiceBean;
import com.project.obs.exception.OnlineBankingException;

public interface IAdminDao {

	public boolean updateRegStatus(int serviceId) throws OnlineBankingException;
	public boolean updateCheckBookStatus(int serviceId) throws OnlineBankingException;
	
	public List<ServiceBean> getServiceIdOfCustomer() throws OnlineBankingException;
	
}
