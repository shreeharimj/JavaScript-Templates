package com.project.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.TransactionBean;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.util.DBConnection;

public class CustomerDaoImpl implements ICustomerDao {

	private static Logger log = Logger.getLogger(CustomerDaoImpl.class);

	public CustomerDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public boolean updateAddress(CustomerBean customer)
			throws OnlineBankingException {
		log.debug("Update Address Called");
		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.UPDATE_MOBILE_ADDRESS_BY_ID;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, customer.getAddress());
			pstmt.setInt(2, customer.getAccountId());
			int count = pstmt.executeUpdate();

			if (count <= 0) {
				log.info("Updation failed");
				return false;
			} else {
				log.debug("Update Address Completed");
				return true;
			}
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Address cannot be updated");

		}

	}

	@Override
	public boolean updatePassword(String oldpassword, int accountId,
			String newpassword) throws OnlineBankingException {
		log.debug("Update Password Called");
		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.UPDATE_LOGIN_PASSWORD;
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, newpassword);
			pstmt.setInt(2, accountId);
			pstmt.setString(3, oldpassword);

			int count = pstmt.executeUpdate();

			if (count <= 0) {
				log.info("Updation failed");
				return false;
			} else {
				log.debug("Update Password Completed");
				return true;
			}
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException(
					"Exception in Dao Password Updation");
		}

	}

	@Override
	public int addPayeeDetails(CustomerBean customer)
			throws OnlineBankingException {
		log.debug("Add Payee Details Called");
		int count;
		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.INSERT_BENIFICIARY;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, customer.getAccountId());
			pstmt.setInt(2, customer.getPayeeAccountId());
			pstmt.setString(3, customer.getNickName());
			count = pstmt.executeUpdate();
			if (count <= 0){
				log.info("Addition failed");
				throw new OnlineBankingException("Payee Not Added!!!!");
			}
			else {
				return count;
			}

		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Exception" + e.getMessage());

		}

	}

	@Override
	public List<CustomerBean> getBenificiary(int id)
			throws OnlineBankingException {
		log.debug("List Beneficiary Called");
		List<CustomerBean> list = new ArrayList<CustomerBean>();
		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.GET_BENIFICIARY;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				CustomerBean bean = new CustomerBean();
				bean.setAccountId(rst.getInt("account_id"));
				bean.setPayeeAccountId(rst.getInt("payee_account_id"));
				bean.setNickName(rst.getString("nick_name"));
				list.add(bean);

			}

			return list;
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Exception" + e.getMessage());
		}

	}

	@Override
	public CustomerBean getPayeeAccountId(int id, String name)
			throws OnlineBankingException {
		log.debug("Get Payee Account Id Called");

		try {
			CustomerBean bean = new CustomerBean();
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.GET_PAYEE_ACC_NO;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			ResultSet rst = pstmt.executeQuery();

			if (rst.next()) {

				bean.setPayeeAccountId(rst.getInt("payee_account_id"));

			}

			return bean;
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Exception" + e.getMessage());
		}

	}

	@Override
	public int addTransactionDetails(TransactionBean bean)
			throws OnlineBankingException {
		log.debug("Add transaction details Called");
		int id = 0;

		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		String query = QueryMapper.INS_TRANSACTIONS;

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, bean.getTransactionDescription());

			pstmt.setString(2, bean.getTransactionType());// TransactionType
			pstmt.setInt(3, bean.getTransactionAmount());// TranAmount
			pstmt.setInt(4, bean.getAccountNo());

			int count = pstmt.executeUpdate();
			if (count <= 0) {
				log.info("Addition failed");
				throw new OnlineBankingException("Insert failed. ");
			}
			query = QueryMapper.SEQUENCE_TRANSACTION_ID;
			pstmt = con.prepareStatement(query);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				id = res.getInt(1);
			} else {
				log.info("Sequence read failed");
				throw new OnlineBankingException(
						"Unable to read from the sequence");
			}
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException(e.getMessage());
		}
		log.debug("Add Payee Details Completed");
		return (id);
	}

	@Override
	public int addCheckRequestDetails(ServiceBean bean)
			throws OnlineBankingException {
		log.debug("Add Cheque Request Called");
		int id = 0;

		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		String query = QueryMapper.INSRT_CHEQUEBOOK_REQUEST;

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "Cheque Book Request");// Service_Description
			pstmt.setDouble(2, bean.getAccountId());// Account_ID
			pstmt.setString(3, "Pending");// Service_status
			int count = pstmt.executeUpdate();
			if (count <= 0) {
				log.info("Addition failed");
				throw new OnlineBankingException("Insert failed. ");
			}
			query = QueryMapper.SEQUENCE_SERVICE_ID;
			pstmt = con.prepareStatement(query);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				id = res.getInt(1);
			} else {
				log.info("Sequence read failed");
				throw new OnlineBankingException(
						"Unable to read from the sequence");
			}
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException(e.getMessage());
		}
		log.debug("Add Cheque Request Completed");
		return (id);

	}

	@Override
	public List<TransactionBean> viewAllTransferDetails(int account_no)
			throws OnlineBankingException {
		log.debug("View all transactions Called");
		Connection con = null;
		List<TransactionBean> list = new ArrayList<TransactionBean>();

		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.GET_MINISTATEMENT;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, account_no);
			ResultSet res = pstmt.executeQuery();
			while (res.next()) {
				TransactionBean bean = new TransactionBean();
				bean.setAccountNo(res.getInt("account_no"));
				bean.setDateofTransaction(res.getDate("Dateoftransaction"));
				bean.setTransactionAmount(res.getInt("tranamount"));
				bean.setTransactionDescription(res
						.getString("tran_description"));
				bean.setTransactionId(res.getInt("transaction_id"));
				bean.setTransactionType(res.getString("transactiontype"));
				list.add(bean);
				// System.out.println(res.getInt("Transaction_ID")+" "+res.getString("Tran_description")+" "+res.getDate("DateofTransaction")+" "+res.getString("TransactionType")+" "+res.getInt("TranAmount")+" "+res.getInt("Account_No"));
			}

		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("ID NOT AVAILABLE "
					+ e.getMessage());
		}
		log.debug("View all transactions Completed");
		return list;

	}

	@Override
	public CustomerBean checkBalance(int id) throws OnlineBankingException {
		log.debug("Check Balance Called");
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		CustomerBean bean = new CustomerBean();
		String query = QueryMapper.GET_ACCOUNT_BALANCE;
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {

				bean.setAccountBalance(rst.getInt("account_balance"));
			}

		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Balance not found!!");
		}
		log.debug("Check Balance Completed");
		return bean;

	}

	@Override
	public void TransferAmountToBenificiary(int accountId1, String payee,
			int amounttransfered, String desc, String type)
			throws OnlineBankingException {
		log.debug("Transfer amount Called");
		int count = 0;
		int balance = 0;
		int payeeaccount = 0;
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		if (con == null) {
			throw new OnlineBankingException("Failed obtain connection.");
		}
		try {

			PreparedStatement pstmt = con
					.prepareStatement(QueryMapper.GET_ACCOUNT_BALANCE);
			pstmt.setInt(1, accountId1);
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {
				balance = rst.getInt(1);
			}
			if ((balance - amounttransfered > 100)) {

				pstmt = con.prepareStatement(QueryMapper.UPDATE_AFTER_TRANSFER);
				pstmt.setInt(1, (balance - amounttransfered));
				pstmt.setInt(2, accountId1);

				count = pstmt.executeUpdate();
			} else {
				throw new OnlineBankingException("maintain minimum balance");

			}
			pstmt = con.prepareStatement(QueryMapper.GET_PAYEE_ACC_NO);
			pstmt.setInt(1, accountId1);
			pstmt.setString(2, payee);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				payeeaccount = rst.getInt(1);

			}
			pstmt = con.prepareStatement(QueryMapper.INS_FUND_TRANSFER);
			pstmt.setInt(1, accountId1);
			pstmt.setInt(2, payeeaccount);
			pstmt.setInt(3, amounttransfered);
			count = pstmt.executeUpdate();
			pstmt = con.prepareStatement(QueryMapper.INS_TRANSACTIONS);
			pstmt.setString(1, desc);
			pstmt.setString(2, type);
			pstmt.setInt(3, amounttransfered);
			pstmt.setInt(4, accountId1);
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException(e.getMessage());
		}
		log.debug("Transfer Amount Completed");

	}

	@Override
	public ServiceBean getChequeBookStatus(ServiceBean service)
			throws OnlineBankingException {
		log.debug("Check Status Called");
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		ServiceBean bean = new ServiceBean();
		try {
			PreparedStatement st = con
					.prepareStatement(QueryMapper.GET_CHEQUE_BOOK_STATUS);
			st.setInt(1, service.getAccountId());
			st.setString(2, "Cheque Book Request");
			ResultSet rst = st.executeQuery();
			if (rst.next()) {
				bean.setServiceStatus(rst.getString("service_status"));
			} else
				throw new OnlineBankingException("Cheque Book not activated");

		} catch (SQLException e) {
			log.error(e);
			System.out.println("Exception Occured!!");
		}
		log.debug("Check Status Completed");
		return bean;
	}

}
