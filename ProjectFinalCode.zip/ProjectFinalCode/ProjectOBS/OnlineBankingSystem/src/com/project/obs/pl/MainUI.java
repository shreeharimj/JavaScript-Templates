package com.project.obs.pl;

import java.util.Scanner;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.service.IUserService;
import com.project.obs.service.UserServiceImpl;

public class MainUI {

	public static void main(String[] args){

		try {
			Scanner sc = new Scanner(System.in);
			int loginAttempts = 0;
			CustomerBean customer = new CustomerBean();
			IUserService userService = new UserServiceImpl();
			UserServiceImpl service = new UserServiceImpl();
			
			while (true) {

				while (loginAttempts <= 3) {
					
					System.out
							.println("WELCOME TO CAPGEMINI ONLINE BANKING SYSTEM!!");
					System.out.println("***********************************");

					System.out.println("[1]Login as Admin");
					System.out.println("[2]Login as Existing Customer");
					System.out.println("[3]Signup as New Customer");
					System.out.println("[4]Quit");
					System.out.println("************************************");
					System.out.println("Please Select:");
					int choice = sc.nextInt();
					sc.nextLine();

					switch (choice) {
					case 1:

						System.out.print("Enter Username: ");
						String userName = sc.next();
						System.out.print("Enter Password: ");
						String password = sc.next();
						loginAttempts++;
						if (loginAttempts <= 2) {
							try {
								String role = userService.getRole(userName,
										password);
								if ("admin".equals(role)) {
									AdminConsole ac = new AdminConsole(userName);
									ac.start();
								}
							} catch (OnlineBankingException e) {
								System.err
										.println("Please check the user name and password");
							}
						} else
							System.out
									.println("Your account is locked. Please try after sometime!!");
						System.out
								.println("******************************************");

						break;

					case 2:

					
							System.out.println("Enter your account id");
							int acccid = sc.nextInt();
							System.out.println("Enter your User Id");
							int userid = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter your Login password");
							String logpass = sc.nextLine();
							loginAttempts++;
							if (loginAttempts <= 2) {

								customer.setUserId(userid);
								customer.setLoginPassword(logpass);
								customer.setAccountId(acccid);

								try {
									CustomerBean bean = userService
											.validateCustomer(customer);

									if (bean.getUserId() == userid
											&& bean.getLoginPassword().equals(
													logpass)) {

										ServiceBean servbean = new ServiceBean();
										servbean.setAccountId(bean.getAccountId());

										ServiceBean servbean1 = userService
												.checkStatus(servbean);
										if (servbean1.getServiceStatus().equals(
												"ACTIVATED")) {
											System.out
													.println("Login Successful! Please enjoy our services");
											System.out
													.println("*****************************************");
											UserConsole uc = new UserConsole(userid);
											uc.start();
										} else {
											System.out
													.println("Your account is not yet activated!! Please contact your customer care!!!");
											System.out
													.println("******************************************");
										}
									} else {
										System.out
												.println("Login failed!! Check the userId and password again");
										System.out
												.println("******************************************");
									}
								} catch (OnlineBankingException e) {
									System.out.println("Sorry!! Login Failed");
									System.out
											.println("******************************************");
								}
							} else
								System.out
										.println("Your account is locked. Please try after sometime!!");
							System.out
									.println("******************************************");
						break;

					case 3:
						System.out
								.println("Enter the Details to open your account: ");
						System.out.println("Enter Customer Details:");
						System.out.println("Enter your Name:");
						String name = sc.nextLine();
						if (service.validateName(name)) {
							System.out.println("Enter your Email:");
							String email = sc.nextLine();
							if (service.validateEmail(email)) {
								System.out.println("Enter your Address:");
								String address = sc.nextLine();
								if (service.validateAddress(address)) {
									System.out.println("Enter your Pancard:");
									String pancard = sc.nextLine();
									if (service.validatePan(pancard)) {
										System.out
												.println("__________________________");
										System.out.println("Enter User Details:");
										System.out
												.println("Enter a unique user id for future logins");
										int uid = sc.nextInt();
										sc.nextLine();
										if (service.validateUserId(uid)) {
											System.out
													.println("Enter Login Password");
											String loginpass = sc.nextLine();
											if (service
													.validateUserPassword(loginpass)) {
												System.out
														.println("Enter Secret Question");
												String secques = sc.nextLine();
												if (service
														.validateQuestion(secques)) {
													System.out
															.println("Enter your Answer");
													String tranpass = sc.nextLine();
													if (service
															.validateAnswer(tranpass)) {
														customer.setCustomerName(name);
														customer.setEmailId(email);
														customer.setAddress(address);
														customer.setPancard(pancard);
														customer.setUserId(uid);
														customer.setLoginPassword(loginpass);
														customer.setSecretQuestion(secques);
														customer.setTransactionPassword(tranpass);

														try {
															int id = userService
																	.addCustomerDetails(customer);

															if (id <= 0) {
																throw new OnlineBankingException(
																		"Cannot add");
															} else {
																System.out
																		.println("Your Details are Added Successfully!!!");
																System.out
																		.println("Your Account number is "
																				+ id);
																System.out
																		.println("Login Again to use your Account");
																System.out
																		.println("*************************************");
															}

														} catch (OnlineBankingException e) {
															System.out
																	.println("****************************************");

														}
													} else
														System.out
																.println("Answer is not proper. Please enter only alphabets");
												} else
													System.out
															.println("Question is not proper. Please enter only alphabets");
											} else
												System.out
														.println("Password is not strong enough. At least 8 chars, At least one digit, At least one lower alpha char and one upper alpha char, At least one char within a set of special chars (@#%$^), Should not contain spaces and tabs");
										} else
											System.out
													.println("User Id not valid. Please enter only digits with minimum 4 digits");
									} else
										System.out
												.println("PanCard not valid. Please enter a proper Id");
								} else
									System.out
											.println("Address not valid. Please enter a valid address.");
							} else
								System.out.println("Email not valid");
						} else
							System.out
									.println("Name not valid. Please enter only Alphabets.");

						break;

					case 4:
						System.out
								.println("Thank You For Using Capgemini Bank!!!!");
						System.out.println("*************************************");
						System.exit(0);
						break;

					default:
						System.out.println("Please enter a proper choice");
						System.out.println("***************************************");
						break;

					}

				}

				sc.close();
			}
		} catch (Exception e) {
			System.out.println("Please enter in proper format");
			System.out.println("********************************************");
			main(new String[] {"a","b","c"});
		}

	}
}
