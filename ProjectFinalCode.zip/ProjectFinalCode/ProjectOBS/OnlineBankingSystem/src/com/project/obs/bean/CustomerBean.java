package com.project.obs.bean;

import java.util.Date;

public class CustomerBean {

	private int accountId;
	private String customerName;
	private String emailId;
	private String address;
	private String pancard;

	private String accountType;
	private int accountBalance;
	private Date openDate;

	private int serviceId;
	private String serviceDescription;
	private Date serviceRaisedDate;
	private String serviceStatus;

	private int userId;
	private String loginPassword;
	private String secretQuestion;
	private String transactionPassword;
	private String lockStatus;

	private int payeeAccountId;
	private String nickName;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public int getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}

	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}

	public String getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public int getPayeeAccountId() {
		return payeeAccountId;
	}

	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public CustomerBean(int accountId, String customerName, String emailId,
			String address, String pancard) {
		super();
		this.accountId = accountId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.address = address;
		this.pancard = pancard;
	}

	public CustomerBean(int accountId, String customerName, String emailId,
			String address, String pancard, String accountType,
			int accountBalance, Date openDate, int serviceId,
			String serviceDescription, Date serviceRaisedDate,
			String serviceStatus, int userId, String loginPassword,
			String secretQuestion, String transactionPassword,
			String lockStatus, int payeeAccountId, String nickName) {
		super();
		this.accountId = accountId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.address = address;
		this.pancard = pancard;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.openDate = openDate;
		this.serviceId = serviceId;
		this.serviceDescription = serviceDescription;
		this.serviceRaisedDate = serviceRaisedDate;
		this.serviceStatus = serviceStatus;
		this.userId = userId;
		this.loginPassword = loginPassword;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
		this.payeeAccountId = payeeAccountId;
		this.nickName = nickName;
	}

	public CustomerBean() {
		super();
	}

}
