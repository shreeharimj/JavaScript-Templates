package com.project.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.User;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.util.DBConnection;

public class UserDaoImpl implements IUserDao {
	private static Logger log = Logger.getLogger(UserDaoImpl.class);

	public UserDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public User getUserByName(String userName) throws OnlineBankingException {
		log.debug("Get user by name Called");
		User user = null;

		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement st = con.prepareStatement(QueryMapper.GET_USER);
			st.setString(1, userName);

			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
			}
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Unable to get user");
		}
		log.debug("Get user by name Completed");
		return user;

	}

	@Override
	public CustomerBean validateCustomer(CustomerBean customer)
			throws OnlineBankingException {
		log.debug("Validate Customer Called");
		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			CustomerBean bean = new CustomerBean();
			String query = QueryMapper.USER_ID_VERIFICATION;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, customer.getUserId());
			pstmt.setString(2, customer.getLoginPassword());
			pstmt.setInt(3, customer.getAccountId());
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {
				bean.setUserId(rst.getInt("user_id"));
				bean.setLoginPassword(rst.getString("login_password"));
				bean.setAccountId(rst.getInt("account_id"));

			}
			log.debug("Validate Customer Completed");
			return bean;
		} catch (SQLException e) {
			log.error(e);
			throw new OnlineBankingException("Exception");
		}

	}

	public int modifyUserId(CustomerBean customer) {
		boolean flag = false;
		System.out.println("************************************************");
		System.out.println("User Id already exist");
		System.out.println("Enter new User Id");
		Scanner sc = new Scanner(System.in);
		int id1 = sc.nextInt();
		int id = 0;
		try {
			Connection con = DBConnection.getConnection();

			String query = QueryMapper.INSERT_INTO_ACCOUNT_MASTER;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "Savings");
			pstmt.setInt(2, 1000);
			int count = pstmt.executeUpdate();
			if (count <= 0)
				throw new OnlineBankingException("Account not created!!!!");
			else {
				query = QueryMapper.INSERT_INTO_CUSTOMER;
				PreparedStatement pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, customer.getCustomerName());
				pstmt1.setString(2, customer.getEmailId());
				pstmt1.setString(3, customer.getAddress());
				pstmt1.setString(4, customer.getPancard());
				int count1 = pstmt1.executeUpdate();
				if (count1 <= 0)
					throw new OnlineBankingException("Customer not Added!!!");
				else {
					query = QueryMapper.INSERT_INTO_USERS;
					PreparedStatement pstmt2 = con.prepareStatement(query);
					pstmt2.setInt(1, id1);
					pstmt2.setString(2, customer.getLoginPassword());
					pstmt2.setString(3, customer.getSecretQuestion());
					pstmt2.setString(4, customer.getTransactionPassword());
					pstmt2.setString(5, "N");
					int count2 = pstmt2.executeUpdate();
					if (count2 <= 0)
						throw new OnlineBankingException("User not Added!!");
					else {
						query = QueryMapper.INSERT_INTO_SERVICE;
						PreparedStatement pstmt3 = con.prepareStatement(query);
						pstmt3.setString(1, "REGISTRATION REQUEST");
						pstmt3.setString(2, "PENDING");
						int count3 = pstmt3.executeUpdate();
						if (count3 <= 0)
							throw new OnlineBankingException(
									"Service tracker not Added!!");
						query = QueryMapper.SEQUENCE_SERVICE_ID;
						PreparedStatement pstmt5 = con.prepareStatement(query);
						ResultSet rst1 = pstmt5.executeQuery();
						if (rst1.next()) {
							int id11 = rst1.getInt(1);
						} else
							throw new OnlineBankingException(
									"Sequence not created for Service!!");

					}
				}

			}
			query = QueryMapper.SEQUENCE_ACCOUNT_ID;
			PreparedStatement pstmt4 = con.prepareStatement(query);
			ResultSet rst = pstmt4.executeQuery();
			if (rst.next()) {
				id = rst.getInt(1);
			} else
				throw new OnlineBankingException(
						"Sequence Not Created for Account!!");
		} catch (OnlineBankingException e) {
			System.out.println("NO");
		} catch (SQLException e) {
			System.out.println("Not at all");
		}
		System.out.println("Your Details are Added Successfully!!!");
		System.out.println("Your Account number is " + id);
		return id;

	}

	@Override
	public int addCustomerDetails(CustomerBean customer)
			throws OnlineBankingException {
		log.debug("Add customer details Called");
		int id = 0;

		try {
			Connection con = DBConnection.getConnection();
			log.debug("Connection Established");
			String query = QueryMapper.INSERT_INTO_ACCOUNT_MASTER;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "Savings");
			pstmt.setInt(2, 1000);
			int count = pstmt.executeUpdate();
			if (count <= 0) {
				log.info("Addition Failed");
				throw new OnlineBankingException("Account not created!!!!");
			} else {
				query = QueryMapper.INSERT_INTO_CUSTOMER;
				PreparedStatement pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, customer.getCustomerName());
				pstmt1.setString(2, customer.getEmailId());
				pstmt1.setString(3, customer.getAddress());
				pstmt1.setString(4, customer.getPancard());
				int count1 = pstmt1.executeUpdate();
				if (count1 <= 0) {
					log.info("Addition Failed");
					throw new OnlineBankingException("Customer not Added!!!");
				} else {
					query = QueryMapper.INSERT_INTO_USERS;
					PreparedStatement pstmt2 = con.prepareStatement(query);
					pstmt2.setInt(1, customer.getUserId());
					pstmt2.setString(2, customer.getLoginPassword());
					pstmt2.setString(3, customer.getSecretQuestion());
					pstmt2.setString(4, customer.getTransactionPassword());
					pstmt2.setString(5, "N");
					int count2 = pstmt2.executeUpdate();
					if (count2 <= 0) {
						log.info("Addition Failed");
						throw new OnlineBankingException("User not Added!!");
					} else {
						query = QueryMapper.INSERT_INTO_SERVICE;
						PreparedStatement pstmt3 = con.prepareStatement(query);
						pstmt3.setString(1, "REGISTRATION REQUEST");
						pstmt3.setString(2, "PENDING");
						int count3 = pstmt3.executeUpdate();
						if (count3 <= 0) {
							log.info("Addition Failed");
							throw new OnlineBankingException(
									"Service tracker not Added!!");
						}
						query = QueryMapper.SEQUENCE_SERVICE_ID;
						PreparedStatement pstmt5 = con.prepareStatement(query);
						ResultSet rst1 = pstmt5.executeQuery();
						if (rst1.next()) {
							int id1 = rst1.getInt(1);
						} else{
							log.info("Sequence read failed");
							throw new OnlineBankingException(
									"Sequence not created for Service!!");
						}
					}
				}

			}
			query = QueryMapper.SEQUENCE_ACCOUNT_ID;
			PreparedStatement pstmt4 = con.prepareStatement(query);
			ResultSet rst = pstmt4.executeQuery();
			if (rst.next()) {
				id = rst.getInt(1);
			} else{
				log.info("Sequence read failed");
				throw new OnlineBankingException(
						"Sequence Not Created for Account!!");
			}
		} catch (SQLException e) {
			log.error(e);
			modifyUserId(customer);

		}
		log.debug("Add customer details Completed");
		return id;

	}

	@Override
	public ServiceBean checkStatus(ServiceBean service)
			throws OnlineBankingException {
		log.debug("Check Status Called");
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		ServiceBean bean = new ServiceBean();
		try {
			PreparedStatement st = con
					.prepareStatement(QueryMapper.CHECK_STATUS);
			st.setInt(1, service.getAccountId());
			st.setString(2, "REGISTRATION REQUEST");
			ResultSet rst = st.executeQuery();
			if (rst.next()) {
				bean.setServiceStatus(rst.getString("service_status"));
			} else
				throw new OnlineBankingException("Service Status not activated");

		} catch (SQLException e) {
			log.error(e);
			System.out.println("Exception Occured!!");
		}
		log.debug("Check Status Completed");
		return bean;
	}

}
