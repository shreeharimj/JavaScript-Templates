package com.project.obs.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.project.obs.exception.OnlineBankingException;

public class DBConnection {

	public static Connection getConnection() throws OnlineBankingException {
		
		Connection con=null;
		try {
			Properties prop = new Properties();
			FileReader fr = new FileReader("resources/jdbc.properties");
			prop.load(fr);
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("dburl");
			String user = prop.getProperty("dbuser");
			String pass = prop.getProperty("dbpass");
			//Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);
		} catch (FileNotFoundException e) {
			throw new OnlineBankingException("JDBC Properties file not found "+e.getMessage());
			
		} catch (IOException e) {
			throw new OnlineBankingException("Unable to read JDBC props file "+e.getMessage());
		
		} catch (SQLException e) {
			throw new OnlineBankingException("Database connection failed "+e.getMessage());
		}
		return (con);
	}
}
