package com.project.obs.service;
import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.exception.OnlineBankingException;

public interface IUserService {
	
	String getRole(String unm,String pwd) throws OnlineBankingException;
	public CustomerBean validateCustomer(CustomerBean customer) throws OnlineBankingException;
	public int addCustomerDetails(CustomerBean customer) throws OnlineBankingException;
	public ServiceBean checkStatus(ServiceBean service) throws OnlineBankingException;
	//public boolean isValid(CustomerBean bean) throws OnlineBankingException;
}
