package com.project.obs.dao;

import java.util.List;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.TransactionBean;
import com.project.obs.exception.OnlineBankingException;

public interface ICustomerDao {
	
	public boolean updateAddress(CustomerBean customer) throws OnlineBankingException;
	public boolean updatePassword(String oldpassword,int accountId,String newpassword) throws OnlineBankingException;
	
	public int addPayeeDetails(CustomerBean customer) throws OnlineBankingException;
	public List<CustomerBean> getBenificiary(int id) throws OnlineBankingException;
	public CustomerBean getPayeeAccountId(int id,String name) throws OnlineBankingException;

	public int addTransactionDetails(TransactionBean bean) throws OnlineBankingException;
	
	public int addCheckRequestDetails(ServiceBean bean ) throws OnlineBankingException;
	
	public List<TransactionBean> viewAllTransferDetails(int account_no ) throws OnlineBankingException;
	public CustomerBean checkBalance(int id) throws OnlineBankingException;
	public void TransferAmountToBenificiary(int accountId1, String payee,int amounttransfered, String desc,String type) throws OnlineBankingException;

	public ServiceBean getChequeBookStatus(ServiceBean service)
			throws OnlineBankingException;
}
