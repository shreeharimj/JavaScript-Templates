package com.project.obs.dao;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.User;
import com.project.obs.exception.OnlineBankingException;

public interface IUserDao {

	User getUserByName(String userName) throws OnlineBankingException;
	public CustomerBean validateCustomer(CustomerBean customer) throws OnlineBankingException;
	public int addCustomerDetails(CustomerBean customer) throws OnlineBankingException;
	public ServiceBean checkStatus(ServiceBean service) throws OnlineBankingException;
}
