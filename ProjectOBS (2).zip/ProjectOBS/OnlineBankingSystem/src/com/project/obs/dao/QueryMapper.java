package com.project.obs.dao;

public class QueryMapper {

	public static final String INSERT_INTO_ACCOUNT_MASTER = "insert into account_master(account_id,account_type,account_balance,open_date) values (account_seq.nextval,?,?,SYSDATE)";
	public static final String INSERT_INTO_CUSTOMER = "insert into customer(account_id,customer_name,email,address,pancard) values (account_seq.currval,?,?,?,?)";
	public static final String INSERT_INTO_USERS = "insert into user_table(account_id,user_id,login_password,secret_question,transaction_password,lock_status) values (account_seq.currval,?,?,?,?,?)";
	public static final String INSERT_INTO_SERVICE = "insert into service_tracker(service_id,service_description,account_id,service_raised_date,service_status) values (service_seq.nextval,?,account_seq.currval,SYSDATE,?)";
	public static final String SEQUENCE_ACCOUNT_ID = "select account_seq.currval from dual";
	public static final String SEQUENCE_SERVICE_ID = "select service_seq.currval from dual";

	public static final String USER_ID_VERIFICATION = "select account_id,user_id,login_password,secret_question,transaction_password,lock_status from user_table where user_id=? and login_password=? and account_id=?";
	public static final String GET_USER_ID_PASS = "select user_id,login_password from user_table where user_id=?";

	public static final String UPDATE_MOBILE_ADDRESS_BY_ID = "update customer set address=? where account_id=?";
	public static final String UPDATE_LOGIN_PASSWORD = "update user_table set login_password=? where account_id=? and login_password=?";

	public static final String INSERT_BENIFICIARY = "INSERT INTO PayeeTable(account_id,payee_account_id,nick_name)VALUES(?,?,?)";
	public static final String GET_BENIFICIARY = "select account_id,payee_account_id,nick_name from PayeeTable where account_id=?";
	public static final String GET_PAYEE_ACC_NO = "select payee_account_id  from payeetable where account_id=? and nick_name=?";

	public static final String INS_FUND_TRANSFER = "INSERT INTO fund_transfer VALUES(fund_seq.NEXTVAL,?,?,SYSDATE,?)";
	public static final String INS_TRANSACTIONS = "INSERT INTO transactions(transaction_id,tran_description,dateoftransaction,transactiontype,tranamount,account_no) VALUES(transaction_seq.NEXTVAL,?,SYSDATE,?,?,?)";
	public static final String INSRT_CHEQUEBOOK_REQUEST = "insert into Service_Tracker values(service_seq.nextval,?,?,SYSDATE,?)";
	public static final String GET_MINISTATEMENT = "SELECT * FROM Transactions WHERE Account_no=?";

	public static final String SEQUENCE_TRANSACTION_ID = "select transaction_seq.currval from dual";
	public static final String GET_ACCOUNT_BALANCE = "select account_balance from account_master where account_id=?";
	public static final String GET_USER = "SELECT * FROM Users WHERE username=?";

	public static final String UPDATE_AFTER_TRANSFER = "update account_master set account_balance=? where account_id=?";
	public static final String SET_REQUEST_STATUS = "update service_tracker set service_status=? where service_status=? and service_description=? and service_id=?";
	public static final String GET_ALL_SERVICE = "select service_id,service_raised_date,service_description,account_id,service_status from service_tracker";
	public static final String CHECK_STATUS = "select service_status from service_tracker where account_id=? and service_description=?";

	public static final String GET_CHEQUE_BOOK_STATUS="select service_status from service_tracker where account_id=? and service_description=?";
}
