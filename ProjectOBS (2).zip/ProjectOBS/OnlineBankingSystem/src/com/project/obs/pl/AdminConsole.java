package com.project.obs.pl;

import java.util.List;
import java.util.Scanner;
import com.project.obs.bean.ServiceBean;
import com.project.obs.exception.OnlineBankingException;
import com.project.obs.service.AdminServiceImpl;
import com.project.obs.service.IAdminService;


public class AdminConsole {

	private IAdminService adminService = new AdminServiceImpl();
	private Scanner sc;
	private String currentUser;

	public AdminConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() {
		try {
			sc = new Scanner(System.in);
			while (true) {
				System.out.println("**************************************");
				System.out.println("[1] Get all Customer Service Details");
				System.out.println("[2] Update Registration Request");
				System.out.println("[3] Update Cheque Book Request");
				System.out.println("[4] Log Out");
				System.out.println("Enter choice");
				int choice = sc.nextInt();
				switch (choice) {

				case 1:
					try {
						List<ServiceBean> list = adminService
								.getServiceIdOfCustomer();

						if (list.isEmpty()) {
							System.out.println("No services to be provided!!!");
						} else {
							for (ServiceBean serv : list) {
								System.out.println("Account ID: "
										+ serv.getAccountId() + " Service ID: "
										+ serv.getServiceId()
										+ " Service Description: "
										+ serv.getServiceDescription());
								System.out.println(" Service Status: "
										+ serv.getServiceStatus()
										+ " Service Raised Date: "
										+ serv.getServiceRaisedDate());
								System.out.println("\n");
							}
							System.out
									.println("****************************************");
						}
					} catch (OnlineBankingException e1) {
						System.out.println("Exception occured during fetching");
					}
					break;
				case 2:
					try {
					System.out.println("Enter Service Id to Be activated");
					int id = sc.nextInt();
					
						boolean flag = adminService.updateRegStatus(id);
						if (flag == true) {
							System.out.println("Account is Activated");
							System.out
									.println("****************************************");
						} else
							System.out.println("Activation not successful or Account already activated");
					} catch (OnlineBankingException e) {
						System.out.println("Exception occured during activation");
					}
					
					break;
				case 3:
					try {
					System.out.println("Enter Service Id to Be activated");
					int id1 = sc.nextInt();
					
						boolean flag = adminService.updateCheckBookStatus(id1);
						if (flag == true) {
							System.out.println("Cheque book is Activated");
							System.out
									.println("****************************************");
						}

						else
							System.out.println("Activation not successful");
					} catch (OnlineBankingException e) {
						System.out.println("Exception occured during activation");
					}
					
					break;

				case 4:
					System.out.println("Visit again!!!");
					System.out.println("*********************************************");
					System.exit(0);
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Please enter in proper format");
			start();
		}

	}

}
