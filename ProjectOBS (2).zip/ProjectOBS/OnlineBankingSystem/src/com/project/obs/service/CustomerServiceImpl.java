package com.project.obs.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.ServiceBean;
import com.project.obs.bean.TransactionBean;
import com.project.obs.dao.CustomerDaoImpl;
import com.project.obs.dao.ICustomerDao;
import com.project.obs.exception.OnlineBankingException;

public class CustomerServiceImpl implements ICustomerService {

	ICustomerDao dao = new CustomerDaoImpl();

	@Override
	public boolean updateAddress(CustomerBean customer)
			throws OnlineBankingException {
		return dao.updateAddress(customer);
	}

	@Override
	public boolean updatePassword(String oldpassword, int accountId,
			String newpassword) throws OnlineBankingException {
		return dao.updatePassword(oldpassword, accountId, newpassword);
	}

	@Override
	public int addPayeeDetails(CustomerBean customer)
			throws OnlineBankingException {
		return dao.addPayeeDetails(customer);
	}

	@Override
	public List<CustomerBean> getBenificiary(int id)
			throws OnlineBankingException {
		return dao.getBenificiary(id);
	}

	@Override
	public CustomerBean getPayeeAccountId(int id, String name)
			throws OnlineBankingException {
		return dao.getPayeeAccountId(id, name);
	}

	@Override
	public int addTransactionDetails(TransactionBean bean)
			throws OnlineBankingException {
		return dao.addTransactionDetails(bean);
	}

	@Override
	public int addCheckRequestDetails(ServiceBean bean)
			throws OnlineBankingException {

		return dao.addCheckRequestDetails(bean);
	}

	@Override
	public List<TransactionBean> viewAllTransferDetails(int account_no)
			throws OnlineBankingException {

		return dao.viewAllTransferDetails(account_no);
	}

	@Override
	public CustomerBean checkBalance(int id) throws OnlineBankingException {
		return dao.checkBalance(id);
	}

	@Override
	public void TransferAmountToBenificiary(int accountId1, String payee,
			int amounttransfered, String desc, String type)
			throws OnlineBankingException {
		dao.TransferAmountToBenificiary(accountId1, payee, amounttransfered,
				desc, type);

	}

	@Override
	public ServiceBean getChequeBookStatus(ServiceBean service)
			throws OnlineBankingException {
		return dao.getChequeBookStatus(service);
	}


}
