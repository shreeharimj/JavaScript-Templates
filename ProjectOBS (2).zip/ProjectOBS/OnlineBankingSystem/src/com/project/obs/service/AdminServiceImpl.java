package com.project.obs.service;

import java.util.List;

import com.project.obs.bean.ServiceBean;
import com.project.obs.dao.AdminDaoImpl;
import com.project.obs.dao.IAdminDao;
import com.project.obs.exception.OnlineBankingException;

public class AdminServiceImpl implements IAdminService{

	IAdminDao dao=new AdminDaoImpl();
	@Override
	public boolean updateRegStatus(int serviceId) throws OnlineBankingException {
		return dao.updateRegStatus(serviceId);
	}
	@Override
	public boolean updateCheckBookStatus(int serviceId)
			throws OnlineBankingException {
		return dao.updateCheckBookStatus(serviceId);
	}
	@Override
	public List<ServiceBean> getServiceIdOfCustomer()
			throws OnlineBankingException {
		return dao.getServiceIdOfCustomer();
	}
	
	

}
