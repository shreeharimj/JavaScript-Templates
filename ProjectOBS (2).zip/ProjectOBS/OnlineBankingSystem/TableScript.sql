SQL> create table users(username varchar2(10),password varchar2(10),role varchar(10));

Table created.

SQL> insert into users values('admin','admin123','admin');

1 row created.

SQL> commit;

Commit complete.




SQL> create table account_master(Account_ID NUMBER(10), Account_Type VARCHAR2(25), Account_Balance NUMBER(15) ,Open_Date DATE);

Table created.

SQL> drop table account_master;

Table dropped.

SQL> create table account_master(Account_ID NUMBER(10) primary key, Account_Type VARCHAR2(25), Account_Balance NUMBER(15) ,Open_Date DATE);

Table created.

SQL> create table customer(Account_ID NUMBER(10) references account_master(account_id), customer_name VARCHAR2(50), Email VARCHAR2(30), Address VARCHAR2(100), Pancard VARCHAR2(15));

Table created.



SQL> create table transactions(Transaction_ID NUMBER primary key,Tran_description VARCHAR2(100), DateofTransaction DATE , TransactionType VARCHAR2(1), TranAmount NUMBER(15) ,Account_No NUMBER(10) references account_master(account_id));

Table created.

SQL> commit;

Commit complete.


SQL> create table service_tracker( Service_ID NUMBER primary key, Service_Description VARCHAR2(100),Account_ID NUMBER references account_master(account_id), Service_Raised_Date DATE ,Service_status VARCHAR2(20));

Table created.


SQL> create table service_tracker( Service_ID NUMBER primary key, Service_Description VARCHAR2(100),Account_ID NUMBER references account_master(account_id), Service_Raised_Date DATE ,Service_status VARCHAR2(20));

Table created.

SQL> create table user_table(Account_ID NUMBER references account_master(account_id),user_id NUMBER unique,login_password VARCHAR2(15),secret_question VARCHAR2(50),Transaction_password VARCHAR2(15),lock_status VARCHAR2(1));

Table created.


SQL> create table fund_transfer(FundTransfer_ID NUMBER ,Account_ID NUMBER(10) references account_master(account_id),Payee_Account_ID NUMBER(10), Date_Of_Transfer DATE, Transfer_Amount NUMBER(15));

Table created.

SQL> create table payeetable(Account_Id NUMBER references account_master(account_id),Payee_Account_Id NUMBER, Nick_name VARCHAR2(40) unique);

Table created.


SQL> create sequence account_seq start with 1000;

Sequence created.

SQL> create sequence transaction_seq start with 100;

Sequence created.

SQL> create sequence service_seq start with 1;

Sequence created.

SQL> create sequence fund_seq start with 10000;

Sequence created.

