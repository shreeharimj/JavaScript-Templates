package com.project.obs.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.project.obs.bean.CustomerBean;
import com.project.obs.bean.TransactionBean;
import com.project.obs.bean.User;
import com.project.obs.dao.CustomerDaoImpl;
import com.project.obs.dao.UserDaoImpl;

public class BankingTest {

	static UserDaoImpl userdao;
	static User userbean;
	static CustomerDaoImpl custdao;
	static CustomerBean custbean;
	static TransactionBean tranbean;
	int id;

	@BeforeClass
	public static void init() {
		userdao = new UserDaoImpl();
		custdao = new CustomerDaoImpl();
		tranbean=new TransactionBean();
		custbean=new CustomerBean();
		userbean=new User();
	}

	@Test
	public void testLoginAdmin() throws Exception {
		String str = "admin";
		User user1 = userdao.getUserByName(str);
		assertNotNull(user1);
	}

	@Test
	public void testLoginUser() throws Exception {
		custbean.setAccountId(1043);
		custbean.setUserId(5555);
		custbean.setLoginPassword("murali");
		CustomerBean bean=userdao.validateCustomer(custbean);
		assertNotNull(bean);
	}

	@Test
	public void testAddressChange() throws Exception {

		custbean.setAccountId(1043);
		custbean.setAddress("Capgemini");
		boolean val = custdao.updateAddress(custbean);
		assertTrue(val);
	}
	
	@Test
	public void testMiniStatements() throws Exception{
	int id=1043;
	List<TransactionBean> bean=custdao.viewAllTransferDetails(id);
	assertNotNull(bean);
	}

}
